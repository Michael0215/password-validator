package com.example.michael.assignment2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity{
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final TextView rules = findViewById(R.id.rules);
        final EditText password = findViewById(R.id.password);
        final Button bt = findViewById(R.id.bt);


        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View vi) {
                validator v = new validator();
                String pass = password.getText().toString();
                if(v.PWformat(pass)==true)
                    rules.setText("Strong");
                else
                    rules.setText("Not strong");
            }

        });


    }
}
